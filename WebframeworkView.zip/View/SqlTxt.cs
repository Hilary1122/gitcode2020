﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using View;

namespace View
{
    public class SqlTxt
    {
        MySQLHelper hlp = new MySQLHelper();
        string conn = ConfigurationManager.AppSettings["TestBasic"].ToString();
        string connstr = ConfigurationManager.AppSettings["Basic104"].ToString();
        public DataTable DWFarm()
        {
            string sql = string.Format(@"select   net_type,farm_id  as 风场ID from Basic.tbl_farm_info where net_type =1000");
            return hlp.ExecuteQuery(connstr, CommandType.Text, sql).Tables[0];
        }

        public DataTable FarmTraceList()
        {
            DataTable dwdt = DWFarm();
            string isfarmid = string.Empty;
            for (int i = 0; i < dwdt.Rows.Count; i++)
            {
                isfarmid += "'" + dwdt.Rows[i]["风场ID"].ToString().Replace("/", "-").ToString() + "',";
            }
            string Iscontact = " and  farm_id not in  (" + isfarmid.TrimEnd(',').ToString().Trim() + ")";

            string sql = string.Format(@"select 
farm_id	风场ID,
farm_name	风场名称,
farm_alias	风场别名,
templeal	项目阶段,
webinfo	外网,
uploaddate	云端监测的外网通道最新上传时间,
wz	网闸,
wzsftptatus	 网闸SFTP状态,
ydgetdate	云端监测的网闸通道最新上传时间,
baidubjb 	摆渡笔记本,
tydjcbduploaddate	 云端监测的摆渡笔记本通道最新上传时间,
odczbbdysuploadstatus	ODC周报中摆渡笔记本上传状态,
odczbbdwsyy	ODC周报中摆渡笔记本未上传原因,
odczbbdnewuploaddate	 ODC周报中摆渡笔记本最新上传时间,
jalilue	伽利略,
zdjialilueconfig	站端伽利略配置状态,
ydjcjialiueuploaddate	云端监测的伽利略通道最新上传时间,
odczbjialilueuploaddatestatue	ODC周报中伽利略上传状态,
odczbjialiluewsloadyy	 ODC周报中伽利略未上传原因,
odczbjialiluenewuploaddate	ODC周报中伽利略最新上传时间,
farm_servicesenvision	风场服务版本,
farm_sh_servicesenvision	守护服务版本,
serviser_wbsyy 	服务未部署原因,
plmftpstatus	PLM的FTP状态,
plmcpm	PLM的剩余磁盘容量,
wtg_num	 总风机数,
czb_wtg_num	出质保风机数,
xjzc_wtg_num	巡检正常风机数,
xjcs_wtg_num	巡检超时风机数,
wxj_wtg_num	无巡检风机数,
farm_new_date	风场最新巡检时间,
wtg_new_date	 风机最新巡检时间,
webstatus as 网络状态,
yxjlv as 优先级
    from basic.farm_trace  where templeal <>'OUTQA'  and   webstatus='超时' {0}",Iscontact);
            return hlp.ExecuteQuery(conn, CommandType.Text, sql).Tables[0];
        }


        public DataTable ListFuseinfo(string action)
        {
            string iswhere = string.Empty;
            if (action == "匹配")
            {
                iswhere += "  and webstatus='超时'  ";
                DataTable dwdt = DWFarm();
                string isfarmid = string.Empty;
                for (int i = 0; i < dwdt.Rows.Count; i++)
                {
                    isfarmid += "'" + dwdt.Rows[i]["风场ID"].ToString().Replace("/", "-").ToString() + "',";
                }
                iswhere += "  and  farm_id  in  (" + isfarmid.TrimEnd(',').ToString().Trim() + ")";
            }
            if (action == "")
            {
                DataTable dwdt = DWFarm();
                string isfarmid = string.Empty;
                for (int i = 0; i < dwdt.Rows.Count; i++)
                {
                    isfarmid += "'" + dwdt.Rows[i]["风场ID"].ToString().Replace("/", "-").ToString() + "',";
                }
                iswhere += "  and  farm_id not  in  (" + isfarmid.TrimEnd(',').ToString().Trim() + ")";
                iswhere += " and webstatus='正常' ";
            }

            string sql = string.Format(@" select 
farm_id	风场ID,
farm_name	风场名称,
farm_alias	风场别名,
templeal	项目阶段,
webinfo	外网,
uploaddate	云端监测的外网通道最新上传时间,
wz	网闸,
wzsftptatus	 网闸SFTP状态,
ydgetdate	云端监测的网闸通道最新上传时间,
baidubjb 	摆渡笔记本,
tydjcbduploaddate	 云端监测的摆渡笔记本通道最新上传时间,
odczbbdysuploadstatus	ODC周报中摆渡笔记本上传状态,
odczbbdwsyy	ODC周报中摆渡笔记本未上传原因,
odczbbdnewuploaddate	 ODC周报中摆渡笔记本最新上传时间,
jalilue	伽利略,
zdjialilueconfig	站端伽利略配置状态,
ydjcjialiueuploaddate	云端监测的伽利略通道最新上传时间,
odczbjialilueuploaddatestatue	ODC周报中伽利略上传状态,
odczbjialiluewsloadyy	 ODC周报中伽利略未上传原因,
odczbjialiluenewuploaddate	ODC周报中伽利略最新上传时间,
farm_servicesenvision	风场服务版本,
farm_sh_servicesenvision	守护服务版本,
serviser_wbsyy 	服务未部署原因,
plmftpstatus	PLM的FTP状态,
plmcpm	PLM的剩余磁盘容量,
wtg_num	 总风机数,
czb_wtg_num	出质保风机数,
xjzc_wtg_num	巡检正常风机数,
xjcs_wtg_num	巡检超时风机数,
wxj_wtg_num	无巡检风机数,
farm_new_date	风场最新巡检时间,
wtg_new_date	 风机最新巡检时间,
webstatus as 网络状态,
yxjlv as 优先级
    from basic.farm_trace  where templeal <>'OUTQA'  {0}", iswhere);
            return hlp.ExecuteQuery(conn, CommandType.Text, sql).Tables[0];
        }

    }
}
