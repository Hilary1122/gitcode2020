﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace View
{
    public partial class View : System.Web.UI.Page
    {

        MySQLHelper hlp = new MySQLHelper();
        string conn = ConfigurationManager.AppSettings["TestBasic"].ToString();
        string connstr = ConfigurationManager.AppSettings["Basic104"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            text1.Value = ViewCotent();
        }

        public void initView()
        {

        }


        public DataTable DWFarm()
        {
            string sql = string.Format(@"select   net_type,farm_id  as 风场ID from Basic.tbl_farm_info where net_type =1000");
            return hlp.ExecuteQuery(connstr, CommandType.Text, sql).Tables[0];
        }

        public static DataTable dt = new DataTable();

        public string ViewCotent()    //Must
        {


            int Errorcount = 0, count = 0;
            //     int Errorcount = 0;
            int ErrorFtpTelnet = 0, countftptelnet = 0;
            int ErrorBDYSC = 0, BDYSC = 0;
            int ErrorBDWSC = 0, BDWSC = 0;
            int ErrorWZ = 0, WZ = 0;



            //string content = "总超时风场" + Errorcount + "个，总超时风机" + count + "个\r\n";
            //content += "FTP或Telnet连接异常风场" + ErrorFtpTelnet + "个，超时风机" + countftptelnet + "个\r\n";
            //content += "摆渡笔记本（未上传)" + ErrorBDWSC + "个，超时风机" + BDWSC + "个\r\n";
            //content += "摆渡笔记本（已上传）" + ErrorBDYSC + "个，超时风机" + BDYSC + "个\r\n";
            //content += "网闸异常" + ErrorBDYSC + "个，超时风机" + WZ + "个\r\n";
            //DataTable dt2 = ListFuseinfo();
            //int xjzcfarmnum = 0;
            //for (int i = 0; i < dt2.Rows.Count; i++)
            //{
            //    xjzcfarmnum += Convert.ToInt32(dt2.Rows[0]["巡检正常风机数"]);
            //}
            //content += "总巡检正常风场" + dt2.Rows.Count + "个\r\n";
            //content += "巡检正常风机" + xjzcfarmnum + "个\r\n";


            string strjson = string.Empty;
            SqlTxt sqls = new SqlTxt();
            DataTable dt = sqls.FarmTraceList();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i]["优先级"]) == 1)
                {
                    if (dt.Rows[i]["ODC周报中摆渡笔记本上传状态"].ToString() == "已上传")
                    {
                        BDYSC += Convert.ToInt32(dt.Rows[i]["巡检超时风机数"]);
                        ErrorBDYSC++;
                    }
                    if (dt.Rows[i]["ODC周报中摆渡笔记本上传状态"].ToString() == "未上传")
                    {
                        BDWSC += Convert.ToInt32(dt.Rows[i]["巡检超时风机数"]);
                        ErrorBDWSC++;
                    }
                    if (dt.Rows[i]["ODC周报中摆渡笔记本上传状态"].ToString() == "")
                    {
                        WZ += Convert.ToInt32(dt.Rows[i]["巡检超时风机数"]);
                        ErrorWZ++;
                    }
                }
                else
                {
                    if (Convert.ToInt32(dt.Rows[i]["优先级"]) == 2)
                    {
                        countftptelnet += Convert.ToInt32(dt.Rows[i]["巡检超时风机数"]);
                        ErrorFtpTelnet++;
                    }
                }
            }
            Errorcount = ErrorFtpTelnet + ErrorBDWSC + ErrorWZ + ErrorBDYSC;
            SqlTxt rst = new SqlTxt();
            DataTable dt2 = rst.ListFuseinfo("");
            int xjzcfarmnum = 0;
            int farmnums = dt2.Rows.Count;
            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                xjzcfarmnum += Convert.ToInt32(dt2.Rows[i]["巡检正常风机数"]);
            }
            strjson += "{";
            strjson += "\"FTPtelnet\":[" + countftptelnet + "],";
            strjson += "\"BaiduBjbWsc\":[" + BDWSC + "],";
            strjson += "\"BaiduBjbYsc\":[" + BDYSC + "],";
            strjson += "\"WzError\":[" + WZ + "],";
            strjson += "\"XjSuccess\":[" + xjzcfarmnum + "]";
            strjson += "}";

            int dwfjs2 = 0;//断网风机数

            DataTable dt4 = rst.ListFuseinfo("匹配");
            for (int i = 0; i < dt4.Rows.Count; i++)
            {
                dwfjs2 += Convert.ToInt32(dt4.Rows[i]["巡检超时风机数"]);
            }
            int dwdfarm = dt4.Rows.Count;//全部超时断网风场数。
            string[] proces = { "需要协助现场处理", "待现场自行上传", "需确认是否设为断网风场", "通知现场自行处理", "无需处理" };
            string[] typeName = { "摆渡笔记本（已上传）", "摆渡笔记本（未上传）", "网闸异常", "FTP或者Telnet异常", "巡检正常" };
            int[] farmnum = { ErrorBDYSC, ErrorBDWSC, ErrorWZ, ErrorFtpTelnet, farmnums };
            int[] wtgnum = { BDYSC, BDWSC, WZ, countftptelnet, xjzcfarmnum };

            string str = string.Empty;
            str += @"<tr style='font-weight:bold;'>
                           <td>巡检状态</td>
                           <td>风场数</td>
                           <td>风机数</td>
                           <td>可处理状态</td>
                       </tr>";
            for (int i = 0; i < typeName.Length; i++)
            {
                str += "<tr>";
                str += "<td>" + typeName[i] + "</td>";
                str += "<td>" + farmnum[i] + "</td>";
                str += "<td>" + wtgnum[i] + "</td>";
                str += "<td>" + proces[i] + "</td>";
                str += "<tr>";
            }
            int errorcount = BDYSC + BDWSC + WZ + countftptelnet;
            int errorfarmcount = ErrorBDYSC + ErrorBDWSC + ErrorWZ + ErrorFtpTelnet;

            string[] errorname = { "正常风场", "超时风场", "断网风场" };
            int[] farmcounts = { farmnums, errorfarmcount, dwdfarm };
            int[] farmwtg = { xjzcfarmnum, errorcount, dwfjs2 };
            string str2 = string.Empty;
            str2 += @"<tr style='font-weight:bold;'>
                           <td>风场状态</td>
                           <td>风场数</td>
                           <td>风机数</td>
                       </tr>";
            for (int i = 0; i < errorname.Length; i++)
            {
                str2 += "<tr>";
                str2 += "<td>" + errorname[i] + "</td>";
                str2 += "<td>" + farmcounts[i] + "</td>";
                str2 += "<td>" + farmwtg[i] + "</td>";
                str2 += "</tr>";
            }

            this.Table2.Value = str2;
            this.Table1.Value = str;

            return strjson;
        }

    }
}